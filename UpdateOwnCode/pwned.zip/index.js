exports.handler = async () => {
  console.log("This function has been pwned!");
};
